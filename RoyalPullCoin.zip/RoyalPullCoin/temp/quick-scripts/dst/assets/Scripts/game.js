
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0debaCk39lL7ILxSjVijJFK', 'game');
// Scripts/game.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    food: cc.Node,
    pin11: cc.Node,
    pin12: cc.Node,
    pin21: cc.Node,
    pin22: cc.Node,
    pin31: cc.Node,
    pin32: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.getPhysicsManager().enabled = true;
    this.isPin11Pulled = false;
    this.isPin12Pulled = false;
    this.isPin21Pulled = false;
    this.isPin22Pulled = false;
    this.isPin31Pulled = false;
    this.isPin32Pulled = false;
    this.pin12.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pin12.runAction(cc.moveTo(0.5, -70 + 141.6083, 482 + 90));
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL2dhbWUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJmb29kIiwiTm9kZSIsInBpbjExIiwicGluMTIiLCJwaW4yMSIsInBpbjIyIiwicGluMzEiLCJwaW4zMiIsIm9uTG9hZCIsImRpcmVjdG9yIiwiZ2V0UGh5c2ljc01hbmFnZXIiLCJlbmFibGVkIiwiaXNQaW4xMVB1bGxlZCIsImlzUGluMTJQdWxsZWQiLCJpc1BpbjIxUHVsbGVkIiwiaXNQaW4yMlB1bGxlZCIsImlzUGluMzFQdWxsZWQiLCJpc1BpbjMyUHVsbGVkIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsImV2ZW50IiwicnVuQWN0aW9uIiwibW92ZVRvIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxJQUFJLEVBQUVKLEVBQUUsQ0FBQ0ssSUFERDtBQUVSQyxJQUFBQSxLQUFLLEVBQUVOLEVBQUUsQ0FBQ0ssSUFGRjtBQUdSRSxJQUFBQSxLQUFLLEVBQUVQLEVBQUUsQ0FBQ0ssSUFIRjtBQUlSRyxJQUFBQSxLQUFLLEVBQUVSLEVBQUUsQ0FBQ0ssSUFKRjtBQUtSSSxJQUFBQSxLQUFLLEVBQUVULEVBQUUsQ0FBQ0ssSUFMRjtBQU1SSyxJQUFBQSxLQUFLLEVBQUVWLEVBQUUsQ0FBQ0ssSUFORjtBQU9STSxJQUFBQSxLQUFLLEVBQUVYLEVBQUUsQ0FBQ0s7QUFQRixHQUhQO0FBYUw7QUFFQU8sRUFBQUEsTUFmSyxvQkFlSTtBQUNMWixJQUFBQSxFQUFFLENBQUNhLFFBQUgsQ0FBWUMsaUJBQVosR0FBZ0NDLE9BQWhDLEdBQTBDLElBQTFDO0FBQ0EsU0FBS0MsYUFBTCxHQUFxQixLQUFyQjtBQUNBLFNBQUtDLGFBQUwsR0FBcUIsS0FBckI7QUFDQSxTQUFLQyxhQUFMLEdBQXFCLEtBQXJCO0FBQ0EsU0FBS0MsYUFBTCxHQUFxQixLQUFyQjtBQUNBLFNBQUtDLGFBQUwsR0FBcUIsS0FBckI7QUFDQSxTQUFLQyxhQUFMLEdBQXFCLEtBQXJCO0FBQ0EsU0FBS2QsS0FBTCxDQUFXZSxFQUFYLENBQ0l0QixFQUFFLENBQUNLLElBQUgsQ0FBUWtCLFNBQVIsQ0FBa0JDLFdBRHRCLEVBRUksVUFBVUMsS0FBVixFQUFpQjtBQUNiLFdBQUtsQixLQUFMLENBQVdtQixTQUFYLENBQXFCMUIsRUFBRSxDQUFDMkIsTUFBSCxDQUFVLEdBQVYsRUFBZSxDQUFDLEVBQUQsR0FBTSxRQUFyQixFQUErQixNQUFNLEVBQXJDLENBQXJCO0FBQ0gsS0FKTCxFQUlPLElBSlA7QUFNSCxHQTdCSTtBQStCTEMsRUFBQUEsS0EvQkssbUJBK0JHLENBRVAsQ0FqQ0ksQ0FtQ0w7O0FBbkNLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGZvb2Q6IGNjLk5vZGUsXG4gICAgICAgIHBpbjExOiBjYy5Ob2RlLFxuICAgICAgICBwaW4xMjogY2MuTm9kZSxcbiAgICAgICAgcGluMjE6IGNjLk5vZGUsXG4gICAgICAgIHBpbjIyOiBjYy5Ob2RlLFxuICAgICAgICBwaW4zMTogY2MuTm9kZSxcbiAgICAgICAgcGluMzI6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIGNjLmRpcmVjdG9yLmdldFBoeXNpY3NNYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XG4gICAgICAgIHRoaXMuaXNQaW4xMVB1bGxlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmlzUGluMTJQdWxsZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5pc1BpbjIxUHVsbGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMuaXNQaW4yMlB1bGxlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmlzUGluMzFQdWxsZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5pc1BpbjMyUHVsbGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMucGluMTIub24oXG4gICAgICAgICAgICBjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCxcbiAgICAgICAgICAgIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgICAgICAgIHRoaXMucGluMTIucnVuQWN0aW9uKGNjLm1vdmVUbygwLjUsIC03MCArIDE0MS42MDgzLCA0ODIgKyA5MCkpO1xuICAgICAgICAgICAgfSwgdGhpc1xuICAgICAgICApO1xuICAgIH0sXG5cbiAgICBzdGFydCgpIHtcblxuICAgIH0sXG5cbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcbn0pO1xuIl19