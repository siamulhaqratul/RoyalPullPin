"use strict";
cc._RF.push(module, '0debaCk39lL7ILxSjVijJFK', 'game');
// Scripts/game.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    food: cc.Node,
    pin11: cc.Node,
    pin12: cc.Node,
    pin21: cc.Node,
    pin22: cc.Node,
    pin31: cc.Node,
    pin32: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.getPhysicsManager().enabled = true;
    this.isPin11Pulled = false;
    this.isPin12Pulled = false;
    this.isPin21Pulled = false;
    this.isPin22Pulled = false;
    this.isPin31Pulled = false;
    this.isPin32Pulled = false;
    this.pin12.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pin12.runAction(cc.moveTo(0.5, -70 + 141.6083, 482 + 90));
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();